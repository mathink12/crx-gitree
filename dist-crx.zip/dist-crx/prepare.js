const container = document.createElement('div')
container.id = 'gitree_container'
container.classList.add('v-application')
document.body.appendChild(container)
